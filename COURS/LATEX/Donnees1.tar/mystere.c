#include <stdio.h>
#include <unistd.h>


int main() {
  int i = 0;
  char id[33];
  snprintf(id,32,"%d",getuid());
  while(id[i] != '\0') {
    putchar('A' + (2*((id[i] - '0' + 2)%10)));
    i++;
  }
  putchar('\n');
  return 0;
}

