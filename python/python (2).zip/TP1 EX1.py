"""Exercice1
Écrire un programme qui demande
deux nombres entiers à l'utilisateur,
puis affiche la somme et le produit
de ces deux nombres.
Que se passe-t-il si l'utilisateur
saisit autre chose que des entiers?
(on demande de le remarquer,
pas de modifier le programme pour
que cela marche quand même)."""

x=int(input('Premier nombre'))
y=int(input('Deuxième nombre'))
print('résultat:', x+y, 'et', x*y)
